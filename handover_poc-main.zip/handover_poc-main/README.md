# handover_poc
Proof of Concept for Handover Reporting running from streamlit

All data is dummy data. However, the feeds are designed to be quickly replicatable from SQL, Excel or any other datafeed
