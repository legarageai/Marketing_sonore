import base64
from flask import Flask, request, jsonify, render_template, Response, redirect, url_for, session, request
import cv2
from deepface import DeepFace
import numpy as np
import csv
import datetime
import numpy as np
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import pandas as pd
import requests

app = Flask(__name__)
app.secret_key = '21062003'

@app.route('/')
def home():
    return render_template('index3.html')

age_categories = {
    'children': (0, 12),
    'teenagers': (13, 19),
    'young_adults': (20, 35),
    'middle_adults': (36, 50),
    'elderly': (51, np.inf)
    }

def categorize_age(age):
    for category, (lower, upper) in age_categories.items():
        if lower <= age <= upper:
            return category
    return 'unknown'  # Si l'âge ne correspond à aucune catégorie


def generate_frames():
    cap = cv2.VideoCapture(0)

    csv_file = open('emotions.csv', 'w', newline='', encoding='utf-8')
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['ID', 'Date', 'Time', 'Age', 'Age Category', 'Gender', 'Emotion', 'Frequency'])

    face_dict = {}

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        
        emotions = DeepFace.analyze(rgb_frame, actions=['age', 'gender', 'emotion'], enforce_detection=False)
        age = emotions[0]['age']
        dominant_emotion = emotions[0]['dominant_emotion']
        gender_scores = emotions[0]['gender']
        
        if gender_scores['Man'] > gender_scores['Woman']:
            dominant_gender = 'Homme'
        else:
            dominant_gender = 'Femme'
        
        face_key = f"{dominant_gender}_{dominant_emotion}"
        
        if face_key in face_dict:
            face_dict[face_key]['Frequency'] += 1
        else:
            face_dict[face_key] = {
                'ID': len(face_dict) + 1,
                'Date': None,
                'Time': None,
                'Age': age,
                'Gender': dominant_gender,
                'Emotion': dominant_emotion,
                'Frequency': 1
            }
        
        current_datetime = datetime.datetime.now()
        date = current_datetime.date()
        time = current_datetime.time()
        age_category = categorize_age(age)
        
        face_dict[face_key]['Date'] = date
        face_dict[face_key]['Time'] = time
        face_dict[face_key]['Age Category'] = age_category
        
        # Écrire les informations dans le fichier CSV
        for face_info in face_dict.values():
            csv_writer.writerow([face_info['ID'], face_info['Date'], face_info['Time'], face_info['Age'], face_info['Age Category'], face_info['Gender'], face_info['Emotion'], face_info['Frequency']])
        
        # Afficher l'image avec les annotations
        cv2.imshow('Emotion Detection', frame)
        
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
           
        # Vérifier si l'utilisateur a appuyé sur la touche 'q' pour quitter
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    csv_file.close()
    cap.release()
    cv2.destroyAllWindows()

    with open('emotions.csv', 'r') as csv_file:
        csv_content = csv_file.read()

    return redirect(url_for('home'))


@app.route('/detect')
def detect():
    session['original_url'] = request.referrer

    # Lancer la génération d'images
    generate_frames()

    # Rediriger l'utilisateur vers l'URL d'origine
    return redirect(session.pop('original_url', '/')) 

@app.route('/get_data')
def get_data():
    # Lisez les données depuis le fichier CSV et préparez-les pour le renvoi
    # Assurez-vous d'adapter cette logique en fonction de la structure de votre CSV
    data = []
    with open('emotions.csv', 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            data.append({
                'age': row['Age'],
                'emotion': row['Emotion'],
                'gender': row['Gender'],
                'frequency': int(row['Frequency'])
            })
    
    return jsonify(data)

@app.route('/generate_playlist', methods=['GET'])
def generate_playlist():
    # Lire les données d'émotion depuis le fichier emotion.csv
    emotion_data = pd.read_csv('emotions.csv')

    # Obtenir les informations d'âge et de genre dominants depuis le fichier emotion.csv
    dominant_age = emotion_data['Age Category'].mode().iloc[0]
    dominant_gender = emotion_data['Gender'].mode().iloc[0]

    # Lire les données musicales depuis le fichier resultats.csv
    music_data = pd.read_csv('resultats.csv')

    # Définir les plages d'âge en fonction du dominant_age
    if dominant_age == 'children':
        year_range = [2009, 2021]
    elif dominant_age == 'teenagers':
        year_range = [2002, 2008]
    elif dominant_age == 'young_adults':
        year_range = [1986, 2001]
    elif dominant_age == 'middle_adults':
        year_range = [1971, 1985]
    elif dominant_age == 'elderly':
        year_range = [-float('inf'), 1970]

    # Filtrer les chansons en fonction de la plage d'année
    filtered_music = music_data[(music_data['year'] >= year_range[0]) & (music_data['year'] <= year_range[1])]

    # Filtrer davantage en fonction du genre dominant
    if dominant_gender == 'Homme':
        filtered_music = filtered_music[(filtered_music['valence'] > 0) & (filtered_music['valence'] < 0.5) &
                                        (filtered_music['danceability'] > 0.7) & (filtered_music['danceability'] < 1) &
                                        (filtered_music['energy'] > 0.7) & (filtered_music['energy'] < 1)]
    elif dominant_gender == 'Femme':
        filtered_music = filtered_music[(filtered_music['valence'] > 0.5) & (filtered_music['valence'] < 1) &
                                        (filtered_music['danceability'] > 0.5) & (filtered_music['danceability'] < 1) &
                                        (filtered_music['energy'] > 0.5) & (filtered_music['energy'] < 1)]

    # Liste pour stocker les informations sur les musiques sélectionnées
    selected_music_info = []

    # Parcourir chaque musique dans la playlist filtrée
    for index, row in filtered_music.iterrows():
        # Récupérer le titre de la musique
        title = row['name']
        carac1 = row['danceability']
        carac2 = row['energy']
        carac3 = row['valence']

        # Rechercher la musique sur l'API iTunes Search en utilisant le titre
        url = f'https://itunes.apple.com/search?term={title}&entity=song&limit=1'
        response = requests.get(url)

        # Vérifier si la requête a réussi
        if response.status_code == 200:
            data = response.json()
            # Vérifier si des résultats ont été trouvés
            if data['resultCount'] > 0:
                # Prendre la première musique dans les résultats
                first_result = data['results'][0]

                # Récupérer l'ID de la musique et le lien Apple Music
                music_id = first_result['trackId']
                apple_music_link = first_result['trackViewUrl']

                # Ajouter les détails de la musique à la liste
                selected_music_info.append({
                    'title': title,
                    'apple_music_id': music_id,
                    'apple_music_link': apple_music_link,
                    'valence': carac3,
                    'Energie': carac1,
                    'Danceability': carac2
                })
            else:
                # Si aucune correspondance n'a été trouvée, ajouter une entrée avec des informations manquantes
                selected_music_info.append({
                    'title': title,
                    'apple_music_id': None,
                    'apple_music_link': None,
                    'valence': None,
                    'Energie': None,
                    'Danceability': None
                })

    # Créer un DataFrame avec les informations des musiques sélectionnées
    selected_music_df = pd.DataFrame(selected_music_info)
    selected_music_df.to_csv('playliste.csv', index=False)

    # Convertir le DataFrame en JSON
    selected_music_json = selected_music_df.to_json(orient='records')

    return jsonify(selected_music_json)

@app.route('/statistics', methods=['GET'])
def statistics():
    # Charger les données à partir des fichiers CSV
    emotion_data = pd.read_csv('emotions.csv')
    
    # Calculer la moyenne des fréquences de visite
    average_frequency = emotion_data['Frequency'].mean()

    # Obtenir la liste des émotions détectées
    emotions_detected = emotion_data['Emotion'].unique()

    # Obtenir le genre dominant
    dominant_gender = emotion_data['Gender'].mode().iloc[0]

    # Obtenir l'âge dominant
    dominant_age = emotion_data['Age'].mode().iloc[0]

    # Obtenir l'émotion dominante
    dominant_emotion = emotion_data['Emotion'].mode().iloc[0]

    # Obtenir l'heure de pointe
    # Convertir la colonne "Time" en format datetime
    emotion_data['Time'] = pd.to_datetime(emotion_data['Time'])  # Utilisez 'Time' ici

    # Extraire l'heure à partir de la colonne "Time"
    emotion_data['hour'] = emotion_data['Time'].dt.hour

    # Regrouper les données par heure et compter le nombre de lignes dans chaque groupe
    hourly_counts = emotion_data.groupby('hour').size()

    # Trouver l'heure de pointe (heure avec le nombre maximal de lignes)
    peak_hour = hourly_counts.idxmax()

    # Convert the Frequency column to regular Python integers
    emotion_data['Frequency'] = emotion_data['Frequency'].astype(int)


    # Filtrer et récupérer les informations sur les musiques sélectionnées depuis le fichier playliste.csv
    filtered_music = pd.read_csv('playliste.csv')
    selected_music_count = len(filtered_music)

    # Créer un document PDF
    pdf_filename = 'music_analysis_report.pdf'
    doc = SimpleDocTemplate(pdf_filename, pagesize=letter)

    # Créer une liste pour contenir les éléments à ajouter au document
    elements = []

    # Ajouter la date de génération du rapport
    now = datetime.datetime.now()
    date_generated = now.strftime("%Y-%m-%d %H:%M:%S")
    date_text = f"Rapport généré le {date_generated}"
    date_paragraph = Paragraph(date_text, getSampleStyleSheet()['Normal'])
    elements.append(date_paragraph)

    report_info = 
    [
    ["Tranches d'âge", "Moyenne des fréquences de visite", "Émotions détectées"],
    [dominant_age, round(average_frequency, 2), ', '.join(emotions_detected)],
    ["Genres détectés", "Genre dominant", "Émotion dominante"],
    [', '.join(f"{gender}: {count}" for gender, count in gender_counts.items()), dominant_gender, dominant_emotion],
    ["Heure de pointe", "Musiques sélectionnées et leur nombre", ""],
    [peak_hour, f"{selected_music_count} musiques", ""]
    ]


    # Créer un tableau à partir des informations
    table = Table(report_info, colWidths=[150, 150, 150])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.orange),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.white),  # Changement ici pour tout le texte
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.black),
        ('GRID', (0, 0), (-1, -1), 1, colors.white),
    ]))

    elements.append(table)

    # Construire le document PDF
    doc.build(elements)
    report_path = f'http://127.0.0.1:5000/{pdf_filename}'
    
    # Convert the peak_hour to a string representation
    peak_hour_str = str(peak_hour)

    # Créer le JSON à renvoyer
    response_data = {
        'peak_hour': peak_hour_str,
        'total_people': int(len(emotion_data)),
        'dominant_emotion': dominant_emotion,
        'report_path': report_path
    }

    return jsonify(response_data)


if __name__ == '__main__':
    app.run(debug=True)